"""A relationship matrix plugin for novelyst

Requires Python 3.6+
Copyright (c) 2023 Peter Triesberger
For further information see https://github.com/peter88213/novelyst_matrix
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import sys
import os
import gettext
import locale
import webbrowser
from pathlib import Path

__all__ = [
    'Error',
    '_',
    'LOCALE_PATH',
    'CURRENT_LANGUAGE',
    'norm_path',
    'string_to_list',
    'list_to_string',
    'ROOT_PREFIX',
    'ARC_PREFIX',
    'ARC_POINT_PREFIX',
    'CHAPTER_PREFIX',
    'SECTION_PREFIX',
    'CHARACTER_PREFIX',
    'LOCATION_PREFIX',
    'ITEM_PREFIX',
    'CH_ROOT',
    'AC_ROOT',
    'CR_ROOT',
    'LC_ROOT',
    'IT_ROOT',
    'BRF_SYNOPSIS_SUFFIX',
    'CHAPTERS_SUFFIX',
    'CHARACTERS_SUFFIX',
    'CHARLIST_SUFFIX',
    'DATA_SUFFIX',
    'ITEMLIST_SUFFIX',
    'ITEMS_SUFFIX',
    'LOCATIONS_SUFFIX',
    'LOCLIST_SUFFIX',
    'MANUSCRIPT_SUFFIX',
    'NOTES_SUFFIX',
    'PARTS_SUFFIX',
    'PLOTLIST_SUFFIX',
    'PLOT_SUFFIX',
    'PROOF_SUFFIX',
    'SECTIONLIST_SUFFIX',
    'SECTIONS_SUFFIX',
    'TODO_SUFFIX',
    'XREF_SUFFIX',
    ]
ROOT_PREFIX = 'rt'
CHAPTER_PREFIX = 'ch'
ARC_PREFIX = 'ac'
SECTION_PREFIX = 'sc'
ARC_POINT_PREFIX = 'ap'
CHARACTER_PREFIX = 'cr'
LOCATION_PREFIX = 'lc'
ITEM_PREFIX = 'it'
CH_ROOT = f'{ROOT_PREFIX}{CHAPTER_PREFIX}'
AC_ROOT = f'{ROOT_PREFIX}{ARC_PREFIX}'
CR_ROOT = f'{ROOT_PREFIX}{CHARACTER_PREFIX}'
LC_ROOT = f'{ROOT_PREFIX}{LOCATION_PREFIX}'
IT_ROOT = f'{ROOT_PREFIX}{ITEM_PREFIX}'

BRF_SYNOPSIS_SUFFIX = '_brf_synopsis'
CHAPTERS_SUFFIX = '_chapters_tmp'
CHARACTERS_SUFFIX = '_characters_tmp'
CHARLIST_SUFFIX = '_charlist_tmp'
DATA_SUFFIX = '_data'
ITEMLIST_SUFFIX = '_itemlist_tmp'
ITEMS_SUFFIX = '_items_tmp'
LOCATIONS_SUFFIX = '_locations_tmp'
LOCLIST_SUFFIX = '_loclist_tmp'
MANUSCRIPT_SUFFIX = '_manuscript_tmp'
NOTES_SUFFIX = '_notes_tmp'
PARTS_SUFFIX = '_parts_tmp'
PLOTLIST_SUFFIX = '_plotlist'
PLOT_SUFFIX = '_plot'
PROOF_SUFFIX = '_proof_tmp'
SECTIONLIST_SUFFIX = '_sectionlist_tmp'
SECTIONS_SUFFIX = '_sections_tmp'
TODO_SUFFIX = '_todo_tmp'
XREF_SUFFIX = '_xref'


class Error(Exception):
    pass


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('novelyst', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''

from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)
import tkinter as tk


def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True



class Node(tk.Label):
    marker = '⬛'
    isLocked = False

    def __init__(self, master, colorFalse='white', colorTrue='black', cnf={}, **kw):
        self.colorFg = colorTrue
        self.colorBg = colorFalse
        self._state = False
        super().__init__(master, cnf, **kw)
        self.config(background=self.colorBg)
        self.config(foreground=self.colorFg)
        self.bind('<Control-Button-1>', self._toggle_state)

    @property
    def state(self):
        return self._state

    @state.setter
    def state(self, newState):
        self._state = newState
        self._set_marker()

    def _set_marker(self):
        if self._state:
            self.config(text=self.marker)
        else:
            self.config(text='')

    def _toggle_state(self, event=None):
        if not self.isLocked:
            self.state = not self._state


class RelationsTable:

    def __init__(self, master, novel, **kwargs):
        self._novel = novel
        self._kwargs = kwargs
        self.draw_matrix(master)

    def draw_matrix(self, master):

        def fill_str(text):
            while len(text) < 7:
                text = f' {text} '
            return text

        colorsBackground = ((self._kwargs['color_bg_00'], self._kwargs['color_bg_01']),
                            (self._kwargs['color_bg_10'], self._kwargs['color_bg_11']))
        columns = []
        col = 0
        bgc = col % 2

        tk.Label(master.topLeft, text=_('Sections')).pack(fill='x')
        tk.Label(master.topLeft, bg=colorsBackground[1][1], text=' ').pack(fill='x')

        row = 0
        self._arcNodes = {}
        self._characterNodes = {}
        self._locationNodes = {}
        self._itemNodes = {}
        for chId in self._novel.tree.get_children(CH_ROOT):
            if self._novel.chapters[chId].chType == 0:
                for scId in self._novel.tree.get_children(chId):
                    bgr = row % 2
                    if self._novel.sections[scId].scType != 0:
                        continue

                    self._characterNodes[scId] = {}
                    self._locationNodes[scId] = {}
                    self._itemNodes[scId] = {}
                    self._arcNodes[scId] = {}

                    tk.Label(master.rowTitles,
                             text=self._novel.sections[scId].title,
                             bg=colorsBackground[bgr][1],
                             justify='left',
                             anchor='w'
                             ).pack(fill='x')
                    row += 1
        bgr = row % 2
        tk.Label(master.rowTitles,
                         text=' ',
                         bg=colorsBackground[bgr][1],
                         ).pack(fill='x')
        tk.Label(master.rowTitles,
                         text=_('Sections'),
                         ).pack(fill='x')

        if self._novel.arcs:
            arcTitleWindow = tk.Frame(master.columnTitles)
            arcTitleWindow.pack(side='left', fill='both')
            tk.Label(arcTitleWindow, text=_('Arcs'), bg=self._kwargs['color_arc_heading']).pack(fill='x')
            arcTypeColumn = tk.Frame(master.display)
            arcTypeColumn.pack(side='left', fill='both')
            arcColumn = tk.Frame(arcTypeColumn)
            arcColumn.pack(fill='both')
            for acId in self._novel.tree.get_children(AC_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                arcTitle = fill_str(self._novel.arcs[acId].shortName)
                tk.Label(arcTitleWindow,
                         text=arcTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(arcColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._arcNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._kwargs['color_arc_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._arcNodes[scId][acId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=arcTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(fill='x', expand=True)
                col += 1
            tk.Label(arcTypeColumn, text=_('Arcs'), bg=self._kwargs['color_arc_heading']).pack(fill='x')

        if self._novel.characters:
            characterTypeColumn = tk.Frame(master.display)
            characterTypeColumn.pack(side='left', fill='both')
            characterColumn = tk.Frame(characterTypeColumn)
            characterColumn.pack(fill='both')
            characterTitleWindow = tk.Frame(master.columnTitles)
            characterTitleWindow.pack(side='left', fill='both')
            tk.Label(characterTitleWindow, text=_('Characters'), bg=self._kwargs['color_character_heading']).pack(fill='x')
            for crId in self._novel.tree.get_children(CR_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                characterTitle = fill_str(self._novel.characters[crId].title)
                tk.Label(characterTitleWindow,
                         text=characterTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(characterColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._characterNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._kwargs['color_character_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._characterNodes[scId][crId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=characterTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(fill='x', expand=True)
                col += 1
            tk.Label(characterTypeColumn, text=_('Characters'), bg=self._kwargs['color_character_heading']).pack(fill='x')

        if self._novel.locations:
            locationTypeColumn = tk.Frame(master.display)
            locationTypeColumn.pack(side='left', fill='both')
            locationColumn = tk.Frame(locationTypeColumn)
            locationColumn.pack(fill='both')
            locationTitleWindow = tk.Frame(master.columnTitles)
            locationTitleWindow.pack(side='left', fill='both')
            tk.Label(locationTitleWindow, text=_('Locations'), bg=self._kwargs['color_location_heading']).pack(fill='x')
            for lcId in self._novel.tree.get_children(LC_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                locationTitle = fill_str(self._novel.locations[lcId].title)
                tk.Label(locationTitleWindow,
                         text=locationTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(locationColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._locationNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._kwargs['color_location_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._locationNodes[scId][lcId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=locationTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(fill='x', expand=True)
                col += 1
            tk.Label(locationTypeColumn, text=_('Locations'), bg=self._kwargs['color_location_heading']).pack(fill='x')

        if self._novel.items:
            itemTypeColumn = tk.Frame(master.display)
            itemTypeColumn.pack(side='left', fill='both')
            itemColumn = tk.Frame(itemTypeColumn)
            itemColumn.pack(fill='both')
            itemTitleWindow = tk.Frame(master.columnTitles)
            itemTitleWindow.pack(side='left', fill='both')
            tk.Label(itemTitleWindow, text=_('Items'), bg=self._kwargs['color_item_heading']).pack(fill='x')
            for itId in self._novel.tree.get_children(IT_ROOT):
                row = 1
                bgr = row % 2
                bgc = col % 2
                itemTitle = fill_str(self._novel.items[itId].title)
                tk.Label(itemTitleWindow,
                         text=itemTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(side='left', fill='x', expand=True)
                row += 1

                columns.append(tk.Frame(itemColumn))
                columns[col].pack(side='left', fill='both', expand=True)
                for scId in self._itemNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=self._kwargs['color_item_node']
                         )
                    node.pack(fill='x', expand=True)
                    self._itemNodes[scId][itId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=itemTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify='left',
                         anchor='w'
                         ).pack(fill='x', expand=True)
                col += 1
            tk.Label(itemTypeColumn, text=_('Items'), bg=self._kwargs['color_item_heading']).pack(fill='x')

    def set_nodes(self):
        for scId in self._arcNodes:

            for acId in self._novel.arcs:
                self._arcNodes[scId][acId].state = (acId in self._novel.sections[scId].scArcs)

            for crId in self._novel.characters:
                self._characterNodes[scId][crId].state = (crId in self._novel.sections[scId].characters)

            for lcId in self._novel.locations:
                self._locationNodes[scId][lcId].state = (lcId in self._novel.sections[scId].locations)

            for itId in self._novel.items:
                self._itemNodes[scId][itId].state = (itId in self._novel.sections[scId].items)

    def get_nodes(self):
        for scId in self._arcNodes:

            self._novel.sections[scId].scArcs = []
            for acId in self._novel.arcs:
                arcSections = self._novel.arcs[acId].sections
                if self._arcNodes[scId][acId].state:
                    self._novel.sections[scId].scArcs.append(acId)
                    if not scId in arcSections:
                        arcSections.append(scId)
                else:
                    if scId in arcSections:
                        arcSections.remove(scId)
                    for tpId in list(self._novel.sections[scId].scTurningPoints):
                        if self._novel.sections[scId].scTurningPoints[tpId] == acId:
                            del self._novel.sections[scId].scTurningPoints[tpId]
                            self._novel.turningPoints[tpId].sectionAssoc = None
                self._novel.arcs[acId].sections = arcSections

            scCharacters = self._novel.sections[scId].characters
            for crId in self._novel.characters:
                if self._characterNodes[scId][crId].state:
                    if not crId in scCharacters:
                        scCharacters.append(crId)
                elif crId in scCharacters:
                        scCharacters.remove(crId)
            self._novel.sections[scId].characters = scCharacters

            scLocations = self._novel.sections[scId].locations
            for lcId in self._novel.locations:
                if self._locationNodes[scId][lcId].state:
                    if not lcId in scLocations:
                        scLocations.append(lcId)
                elif lcId in scLocations:
                        scLocations.remove(lcId)
            self._novel.sections[scId].locations = scLocations

            scItems = self._novel.sections[scId].items
            for itId in self._novel.items:
                if self._itemNodes[scId][itId].state:
                    if itId in scItems:
                        scItems.append(itId)
                elif not itId in scItems:
                        scItems.remove(itId)

            self._novel.sections[scId].items = scItems

import platform
from tkinter import ttk


class TableFrame(ttk.Frame):

    def __init__(self, parent, *args, **kw):

        ttk.Frame.__init__(self, parent, *args, **kw)

        scrollY = ttk.Scrollbar(self, orient='vertical', command=self.yview)
        scrollY.pack(fill='y', side='right', expand=False)
        scrollX = ttk.Scrollbar(self, orient='horizontal', command=self.xview)
        scrollX.pack(fill='x', side='bottom', expand=False)

        leftColFrame = ttk.Frame(self)
        leftColFrame.pack(side='left', fill='both', expand=False)

        self.topLeft = ttk.Frame(leftColFrame)
        self.topLeft.pack(anchor='w', fill='x', expand=False)

        rowTitlesFrame = ttk.Frame(leftColFrame)
        rowTitlesFrame.pack(fill='both', expand=True)
        self._rowTitlesCanvas = tk.Canvas(rowTitlesFrame, bd=0, highlightthickness=0)
        self._rowTitlesCanvas.configure(yscrollcommand=scrollY.set)
        self._rowTitlesCanvas.pack(side='left', fill='both', expand=True)
        self._rowTitlesCanvas.xview_moveto(0)
        self._rowTitlesCanvas.yview_moveto(0)

        self.rowTitles = ttk.Frame(self._rowTitlesCanvas)
        self._rowTitlesCanvas.create_window(0, 0, window=self.rowTitles, anchor='nw', tags="self.rowTitles")

        def _configure_rowTitles(event):
            size = (self.rowTitles.winfo_reqwidth(), self.rowTitles.winfo_reqheight())
            self._rowTitlesCanvas.config(scrollregion="0 0 %s %s" % size)

            if self.rowTitles.winfo_reqwidth() != self._rowTitlesCanvas.winfo_width():
                self._rowTitlesCanvas.config(width=self.rowTitles.winfo_reqwidth())

        self.rowTitles.bind('<Configure>', _configure_rowTitles)

        rightColFrame = ttk.Frame(self)
        rightColFrame.pack(side='left', anchor='nw', fill='both', expand=True)

        columnTitlesFrame = ttk.Frame(rightColFrame)
        columnTitlesFrame.pack(fill='x', anchor='nw', expand=False)
        self._columnTitlesCanvas = tk.Canvas(columnTitlesFrame, bd=0, highlightthickness=0)
        self._columnTitlesCanvas.configure(xscrollcommand=scrollX.set)
        self._columnTitlesCanvas.pack(side='left', fill='both', expand=True)
        self._columnTitlesCanvas.xview_moveto(0)
        self._columnTitlesCanvas.yview_moveto(0)

        self.columnTitles = ttk.Frame(self._columnTitlesCanvas)
        self._columnTitlesCanvas.create_window(0, 0, window=self.columnTitles, anchor='nw', tags="self.columnTitles")

        def _configure_columnTitles(event):
            size = (self.columnTitles.winfo_reqwidth(), self.columnTitles.winfo_reqheight())
            self._columnTitlesCanvas.config(scrollregion="0 0 %s %s" % size)

            if self.columnTitles.winfo_reqwidth() != self._columnTitlesCanvas.winfo_width():
                self._columnTitlesCanvas.config(width=self.columnTitles.winfo_reqwidth())
            if self.columnTitles.winfo_reqheight() != self._columnTitlesCanvas.winfo_height():
                self._columnTitlesCanvas.config(height=self.columnTitles.winfo_reqheight())

        self.columnTitles.bind('<Configure>', _configure_columnTitles)

        displayFrame = ttk.Frame(rightColFrame)
        displayFrame.pack(fill='both', expand=True)
        self._displayCanvas = tk.Canvas(displayFrame, bd=0, highlightthickness=0)
        self._displayCanvas.configure(xscrollcommand=scrollX.set)
        self._displayCanvas.configure(yscrollcommand=scrollY.set)
        self._displayCanvas.pack(side='left', fill='both', expand=True)
        self._displayCanvas.xview_moveto(0)
        self._displayCanvas.yview_moveto(0)

        self.display = ttk.Frame(self._displayCanvas)
        self._displayCanvas.create_window(0, 0, window=self.display, anchor='nw', tags="self.display")

        def _configure_display(event):
            size = (self.display.winfo_reqwidth(), self.display.winfo_reqheight())
            self._displayCanvas.config(scrollregion="0 0 %s %s" % size)
            if self.display.winfo_reqwidth() != self._displayCanvas.winfo_width():
                self._displayCanvas.config(width=self.display.winfo_reqwidth())

        self.display.bind('<Configure>', _configure_display)
        if platform.system() == 'Linux':
            self._rowTitlesCanvas.bind_all("<Button-4>", self.on_mouse_wheel)
            self._rowTitlesCanvas.bind_all("<Button-5>", self.on_mouse_wheel)
            self._displayCanvas.bind_all("<Button-4>", self.on_mouse_wheel)
            self._displayCanvas.bind_all("<Button-5>", self.on_mouse_wheel)

            self._rowTitlesCanvas.bind_all("<Shift-Button-4>", self.on_shift_mouse_wheel)
            self._rowTitlesCanvas.bind_all("<Shift-Button-5>", self.on_shift_mouse_wheel)
            self._displayCanvas.bind_all("<Shift-Button-4>", self.on_shift_mouse_wheel)
            self._displayCanvas.bind_all("<Shift-Button-5>", self.on_shift_mouse_wheel)
        else:
            self._rowTitlesCanvas.bind_all("<MouseWheel>", self.on_mouse_wheel)
            self._displayCanvas.bind_all("<MouseWheel>", self.on_mouse_wheel)

            self._rowTitlesCanvas.bind_all("<Shift-MouseWheel>", self.on_shift_mouse_wheel)
            self._displayCanvas.bind_all("<Shift-MouseWheel>", self.on_shift_mouse_wheel)

    def destroy(self):
        self.display.unbind('<Configure>')
        if platform.system() == 'Linux':
            self._rowTitlesCanvas.unbind_all("<Button-4>")
            self._rowTitlesCanvas.unbind_all("<Button-5>")
            self._displayCanvas.unbind_all("<Button-4>")
            self._displayCanvas.unbind_all("<Button-5>")

            self._rowTitlesCanvas.unbind_all("<Shift-Button-4>")
            self._rowTitlesCanvas.unbind_all("<Shift-Button-5>")
            self._displayCanvas.unbind_all("<Shift-Button-4>")
            self._displayCanvas.unbind_all("<Shift-Button-5>")
        else:
            self._rowTitlesCanvas.unbind_all("<MouseWheel>")
            self._displayCanvas.unbind_all("<MouseWheel>")

            self._rowTitlesCanvas.unbind_all("<Shift-MouseWheel>")
            self._displayCanvas.unbind_all("<Shift-MouseWheel>")
        super().destroy()

    def yview(self, *args):
        self._rowTitlesCanvas.yview(*args)
        self._displayCanvas.yview(*args)

    def xview(self, *args):
        self._columnTitlesCanvas.xview(*args)
        self._displayCanvas.xview(*args)

    def yview_scroll(self, *args):
        if not self._displayCanvas.yview() == (0.0, 1.0):
            self._rowTitlesCanvas.yview_scroll(*args)
            self._displayCanvas.yview_scroll(*args)

    def xview_scroll(self, *args):
        if not self._displayCanvas.xview() == (0.0, 1.0):
            self._columnTitlesCanvas.xview_scroll(*args)
            self._displayCanvas.xview_scroll(*args)

    def on_mouse_wheel(self, event):
        if platform.system() == 'Windows':
            self.yview_scroll(int(-1 * (event.delta / 120)), "units")
        elif platform.system() == 'Darwin':
            self.yview_scroll(int(-1 * event.delta), "units")
        else:
            if event.num == 4:
                self.yview_scroll(-1, "units")
            elif event.num == 5:
                self.yview_scroll(1, "units")

    def on_shift_mouse_wheel(self, event):
        if platform.system() == 'Windows':
            self.xview_scroll(int(-1 * (event.delta / 120)), "units")
        elif platform.system() == 'Darwin':
            self.xview_scroll(int(-1 * event.delta), "units")
        else:
            if event.num == 4:
                self.xview_scroll(-1, "units")
            elif event.num == 5:
                self.xview_scroll(1, "units")



class TableManager(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')

    def __init__(self, plugin, ui, **kwargs):
        self._ui = ui
        self._plugin = plugin
        self._kwargs = kwargs
        super().__init__()

        self._statusText = ''

        self.geometry(kwargs['window_geometry'])
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        self.bind(self._KEY_QUIT_PROGRAM[0], self.on_quit)

        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        self.mainWindow = TableFrame(self)

        if self._ui.novel is not None:
            self._relationsTable = RelationsTable(self.mainWindow, self._ui.novel, **self._kwargs)
            self._relationsTable.set_nodes()
        self.isOpen = True
        self.mainWindow.pack(fill='both', expand=True, padx=2, pady=2)

        self._ui.views.append(self)

        self._skipUpdate = False
        self.bind('<Control-Button-1>', self.on_element_change)

    def lock(self):
        Node.isLocked = True

    def on_quit(self, event=None):
        self.isOpen = False
        self._plugin.kwargs['window_geometry'] = self.winfo_geometry()
        self.mainWindow.destroy()
        self.destroy()

        self._ui.views.remove(self)

    def unlock(self):
        Node.isLocked = False

    def update(self):
        if self.isOpen:
            if not self._skipUpdate:
                self.mainWindow.pack_forget()
                self.mainWindow.destroy()
                self.mainWindow = TableFrame(self)
                self.mainWindow.pack(fill='both', expand=True, padx=2, pady=2)
                self._relationsTable.draw_matrix(self.mainWindow)
                self._relationsTable.set_nodes()

    def on_element_change(self, event=None):
        self._skipUpdate = True
        self._relationsTable.get_nodes()
        self._skipUpdate = False

SETTINGS = dict(
        window_geometry='600x800',
        color_bg_00='gray80',
        color_bg_01='gray85',
        color_bg_10='gray95',
        color_bg_11='white',
        color_arc_heading='royalblue1',
        color_arc_node='royalblue3',
        color_character_heading='goldenrod1',
        color_character_node='goldenrod3',
        color_location_heading='coral1',
        color_location_node='coral3',
        color_item_heading='aquamarine1',
        color_item_node='aquamarine3',
        )
OPTIONS = dict(
        )

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('novelyst_matrix', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Matrix')
PLUGIN = f'{APPLICATION} plugin v2.0.5'


class Plugin:
    """novelyst relationship matrix plugin class.
    
    Public methods:
        disable_menu() -- disable menu entries when no project is open.
        enable_menu() -- enable menu entries when a project is open.   
        on_quit() -- Apply changes and close the window.
        on_close() -- Apply changes and close the window.
    """
    VERSION = '2.0.5'
    NOVELYST_API = '5.0'
    DESCRIPTION = 'A section relationship table'
    URL = 'https://peter88213.github.io/novelyst_matrix'
    _HELP_URL = 'https://peter88213.github.io/novelyst_matrix/usage'

    def install(self, ui):
        """Add a submenu to the 'Tools' menu.
        
        Positional arguments:
            ui -- reference to the NovelystTk instance of the application.
        """
        self._ui = ui
        self._matrixViewer = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.novelyst/config'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/matrix.ini'
        self.configuration = Configuration(SETTINGS, OPTIONS)
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        self.kwargs.update(self.configuration.options)

        self._ui.toolsMenu.add_command(label=APPLICATION, command=self._start_ui)
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

        self._ui.helpMenu.add_command(label=_('Matrix plugin Online help'), command=lambda: webbrowser.open(self._HELP_URL))

    def _start_ui(self):
        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                self._matrixViewer.lift()
                self._matrixViewer.focus()
                return

        self._matrixViewer = TableManager(self, self._ui, **self.kwargs)
        self._matrixViewer.title(f'{self._ui.novel.title} - {PLUGIN}')
        set_icon(self._matrixViewer, icon='mLogo32', default=False)

    def disable_menu(self):
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

    def enable_menu(self):
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')

    def on_close(self):
        self.on_quit()

    def on_quit(self):
        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                self._matrixViewer.on_quit()

        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)
