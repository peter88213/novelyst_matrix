"""A project matrix manager plugin for novelyst.

Requires Python 3.6+
Copyright (c) 2022 Peter Triesberger
For further information see https://github.com/peter88213/novelyst_matrix
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
"""
import os
from pathlib import Path
import sys
import gettext
import locale

__all__ = ['Error',
           '_',
           'norm_path',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           'APPLICATION',
           'PLUGIN',
           'SERIES_PREFIX',
           'BOOK_PREFIX',
           ]


class Error(Exception):
    """Base class for exceptions."""


# Initialize localization.
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
CURRENT_LANGUAGE = locale.getlocale()[0][:2]
try:
    t = gettext.translation('novelyst_matrix', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Matrix')
PLUGIN = f'{APPLICATION} plugin v0.3.0'
SERIES_PREFIX = 'sr'
BOOK_PREFIX = 'bk'


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)

import tkinter as tk
from tkinter import ttk
from tkinter import messagebox


class Node(tk.Label):
    """A visual matrix node, representing a boolean value.
    
    Class variables:
        isModified -- Boolean: True, if at least one instance has changed its state.
    
    Properties:
        state -- Boolean: Node state. Changes its value and color when clicked on.
    """
    isModified = False

    def __init__(self, master, colorFalse='white', colorTrue='black', cnf={}, **kw):
        """Place the node to the master widget.
        
        Optional arguments:
            colorFalse -- str: node color when status is False.
            colorTrue -- str: node color when status is True.
        """
        self.colorTrue = colorTrue
        self.colorFalse = colorFalse
        self._state = False
        super().__init__(master, cnf, **kw)
        self._set_color()
        self.bind('<Button-1>', self._toggle_state)

    @property
    def state(self):
        return self._state

    @state.setter
    def state(self, newState):
        self._state = newState
        self._set_color()

    def _set_color(self):
        if self._state:
            self.config(background=self.colorTrue)
        else:
            self.config(background=self.colorFalse)

    def _toggle_state(self, event=None):
        self.state = not self._state
        Node.isModified = True


class Matrix:
    """Represent a matrix of relationships. 
    
    Public methods:
        set_nodes -- Loop through all nodes, setting states.
        get_nodes -- Loop through all nodes, modifying the scenes according to the states.
    
    The visual part consists of one frame per column, each containing 
    one node per row. 
    The logical part consists of one dictionary per element type (protected instance variables):
    {scene ID: {element Id: node}}
    """

    def __init__(self, master, novel):
        """Draw the matrix with blank nodes.
        
        Positional arguments:
            novel -- Novel: Project reference.
            
        """
        self._novel = novel
        colorsBackground = (('white', 'gray95'), ('gray85', 'gray80'))
        colorsCharacter = (('goldenrod3', 'orange3'), ('goldenrod4', 'orange4'))
        colorsLocation = (('brown3', 'red3'), ('brown4', 'red4'))
        colorsItem = (('green3', 'blue3'), ('green4', 'blue4'))
        colorsArc = (('green3', 'blue3'), ('green4', 'blue4'))
        row = 0
        bgr = row % 2
        col = 0
        bgc = col % 2
        columns = []
        columns.append(tk.Frame(master))
        columns[col].pack(side=tk.LEFT)
        tk.Label(columns[col], text=' ', bg=colorsBackground[bgr][bgc]).pack(fill=tk.X)

        #--- Scene title column.
        for chId in novel.chapters:
            for scId in novel.chapters[chId].srtScenes:
                row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=novel.scenes[scId].title,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(fill=tk.X)

        #--- Arc columns.
        self._arcNodes = {}
        self._arcs = []
        self._scnArcs = {}
        for chId in novel.chapters:
            for scId in novel.chapters[chId].srtScenes:
                self._arcNodes[scId] = {}
                if novel.scenes[scId].scnArcs:
                    self._scnArcs[scId] = string_to_list(novel.scenes[scId].scnArcs)
                    for arc in self._scnArcs[scId]:
                        if not arc in self._arcs:
                            self._arcs.append(arc)
                else:
                    self._scnArcs[scId] = []
        for arc in self._arcs:
            row = 0
            bgr = row % 2
            col += 1
            bgc = col % 2
            columns.append(tk.Frame(master))
            columns[col].pack(side=tk.LEFT)
            tk.Label(columns[col],
                     text=arc,
                     bg=colorsBackground[bgr][bgc],
                     justify=tk.LEFT,
                     anchor=tk.W
                     ).pack(fill=tk.X)
            for scId in self._scnArcs:
                row += 1
                bgr = row % 2
                node = Node(columns[col],
                     colorFalse=colorsBackground[bgr][bgc],
                     colorTrue=colorsArc[bgr][bgc]
                     )
                node.pack(fill=tk.X)
                self._arcNodes[scId][arc] = node

        #--- Character columns.
        self._characterNodes = {}
        for chId in novel.chapters:
            for scId in novel.chapters[chId].srtScenes:
                self._characterNodes[scId] = {}
        for crId in novel.characters:
            row = 0
            bgr = row % 2
            col += 1
            bgc = col % 2
            columns.append(tk.Frame(master))
            columns[col].pack(side=tk.LEFT)
            tk.Label(columns[col],
                     text=novel.characters[crId].title,
                     bg=colorsBackground[bgr][bgc],
                     justify=tk.LEFT,
                     anchor=tk.W
                     ).pack(fill=tk.X)
            for chId in novel.chapters:
                for scId in novel.chapters[chId].srtScenes:
                    row += 1
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=colorsCharacter[bgr][bgc]
                         )
                    node.pack(fill=tk.X)
                    self._characterNodes[scId][crId] = node

        #--- Location columns.
        self._locationNodes = {}
        for chId in novel.chapters:
            for scId in novel.chapters[chId].srtScenes:
                self._locationNodes[scId] = {}
        for lcId in novel.locations:
            row = 0
            bgr = row % 2
            col += 1
            bgc = col % 2
            columns.append(tk.Frame(master))
            columns[col].pack(side=tk.LEFT)
            tk.Label(columns[col],
                     text=novel.locations[lcId].title,
                     bg=colorsBackground[bgr][bgc],
                     justify=tk.LEFT,
                     anchor=tk.W
                     ).pack(fill=tk.X)
            for chId in novel.chapters:
                for scId in novel.chapters[chId].srtScenes:
                    row += 1
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=colorsLocation[bgr][bgc]
                         )
                    node.pack(fill=tk.X)
                    self._locationNodes[scId][lcId] = node

        #--- Item columns.
        self._itemNodes = {}
        for chId in novel.chapters:
            for scId in novel.chapters[chId].srtScenes:
                self._itemNodes[scId] = {}
        for itId in novel.items:
            row = 0
            bgr = row % 2
            col += 1
            bgc = col % 2
            columns.append(tk.Frame(master))
            columns[col].pack(side=tk.LEFT)
            tk.Label(columns[col],
                     text=novel.items[itId].title,
                     bg=colorsBackground[bgr][bgc],
                     justify=tk.LEFT,
                     anchor=tk.W
                     ).pack(fill=tk.X)
            for chId in novel.chapters:
                for scId in novel.chapters[chId].srtScenes:
                    row += 1
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=colorsItem[bgr][bgc]
                         )
                    node.pack(fill=tk.X)
                    self._itemNodes[scId][itId] = node

    def set_nodes(self):
        """Loop through all nodes, setting states."""
        for scId in self._arcNodes:
            for arc in self._arcs:
                try:
                    self._arcNodes[scId][arc].state = (arc in self._scnArcs[scId])
                except TypeError:
                    pass

        for scId in self._characterNodes:
            for crId in self._novel.characters:
                try:
                    self._characterNodes[scId][crId].state = (crId in self._novel.scenes[scId].characters)
                except TypeError:
                    pass

        for scId in self._locationNodes:
            for lcId in self._novel.locations:
                try:
                    self._locationNodes[scId][lcId].state = (lcId in self._novel.scenes[scId].locations)
                except TypeError:
                    pass

        for scId in self._itemNodes:
            for itId in self._novel.items:
                try:
                    self._itemNodes[scId][itId].state = (itId in self._novel.scenes[scId].items)
                except TypeError:
                    pass

    def get_nodes(self):
        """Loop through all nodes, modifying the scenes according to the states."""
        for scId in self._arcNodes:
            arcs = []
            for arc in self._arcs:
                try:
                    node = self._arcNodes[scId][arc]
                except TypeError:
                    pass
                else:
                    if node.state:
                        arcs.append(arc)
            self._novel.scenes[scId].scnArcs = list_to_string(arcs)

        for scId in self._characterNodes:
            self._novel.scenes[scId].characters = []
            for crId in self._novel.characters:
                try:
                    node = self._characterNodes[scId][crId]
                except TypeError:
                    pass
                else:
                    if node.state:
                        self._novel.scenes[scId].characters.append(crId)

        for scId in self._locationNodes:
            self._novel.scenes[scId].locations = []
            for lcId in self._novel.locations:
                try:
                    node = self._locationNodes[scId][lcId]
                except TypeError:
                    pass
                else:
                    if node.state:
                        self._novel.scenes[scId].locations.append(lcId)

        for scId in self._itemNodes:
            self._novel.scenes[scId].items = []
            for itId in self._novel.items:
                try:
                    node = self._itemNodes[scId][itId]
                except TypeError:
                    pass
                else:
                    if node.state:
                        self._novel.scenes[scId].items.append(itId)


def string_to_list(text, divider=';'):
    """Convert a string into a list with unique elements.
    
    Positional arguments:
        text -- string containing divider-separated substrings.
        
    Optional arguments:
        divider -- string that divides the substrings.
    
    Split a string into a list of strings. Retain the order, but discard duplicates.
    Remove leading and trailing spaces, if any.
    Return a list of strings.
    If an error occurs, return an empty list.
    """
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    """Join strings from a list.
    
    Positional arguments:
        elements -- list of elements to be concatenated.
        
    Optional arguments:
        divider -- string that divides the substrings.
    
    Return a string which is the concatenation of the 
    members of the list of strings "elements", separated by 
    a comma plus a space. The space allows word wrap in 
    spreadsheet cells.
    If an error occurs, return an empty string.
    """
    try:
        text = divider.join(elements)
        return text

    except:
        return ''

from configparser import ConfigParser


class Configuration:
    """Application configuration, representing an INI file.

        INI file sections:
        <self._sLabel> - Strings
        <self._oLabel> - Boolean values

    Public methods:
        set(settings={}, options={}) -- set the entire configuration without writing the INI file.
        read(iniFile) -- read a configuration file.
        write(iniFile) -- save the configuration to iniFile.

    Public instance variables:    
        settings - dictionary of strings
        options - dictionary of boolean values
    """

    def __init__(self, settings={}, options={}):
        """Initalize attribute variables.

        Optional arguments:
            settings -- default settings (dictionary of strings)
            options -- default options (dictionary of boolean values)
        """
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def set(self, settings=None, options=None):
        """Set the entire configuration without writing the INI file.

        Optional arguments:
            settings -- new settings (dictionary of strings)
            options -- new options (dictionary of boolean values)
        """
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def read(self, iniFile):
        """Read a configuration file.
        
        Positional arguments:
            iniFile -- str: path configuration file path.
            
        Settings and options that can not be read in, remain unchanged.
        """
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def write(self, iniFile):
        """Save the configuration to iniFile.

        Positional arguments:
            iniFile -- str: path configuration file path.
        """
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)

SETTINGS = dict(
    last_open='',
    tree_width='300',
)
OPTIONS = {}


class MatrixTk(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')

    def __init__(self, ui, position, configDir):
        self._ui = ui
        super().__init__()

        #--- Load configuration.
        self.iniFile = f'{configDir}/matrix.ini'
        self.configuration = Configuration(SETTINGS, OPTIONS)
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        # Read the file path from the configuration file.

        self.title(PLUGIN)
        self._statusText = ''

        self.geometry(position)
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        self.bind(self._KEY_QUIT_PROGRAM[0], self.on_quit)

        #--- Main menu.
        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        #--- Main window.
        self.mainWindow = ttk.Frame(self)
        self.mainWindow.pack(fill=tk.BOTH, padx=2, pady=2)

        #--- The Matrix.
        Node.isModified = False
        if self._ui.novel is not None:
            self._matrix = Matrix(self.mainWindow, self._ui.novel)
            self._matrix.set_nodes()

    #--- Application related methods.

    def on_quit(self, event=None):

        #--- Apply changes.
        if Node.isModified:
            if messagebox.askyesno(PLUGIN, f"{_('Apply changes')}?"):
                self._matrix.get_nodes()
                self._ui.prjFile.write()
                self._ui.refresh_tree()

        #--- Save project specific configuration.
        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)
        self.destroy()
        self.isOpen = False

DEFAULT_FILE = 'matrix.pwc'


class Plugin:
    """novelyst matrix manager plugin class.
    
    Public methods:
        disable_menu() -- disable menu entries when no project is open.
        enable_menu() -- enable menu entries when a project is open.    
    """
    VERSION = '0.3.0'
    NOVELYST_API = '4.0'
    DESCRIPTION = 'A book/series matrix manager'
    URL = 'https://peter88213.github.io/novelyst_matrix'

    def install(self, ui):
        """Add a submenu to the 'Tools' menu.
        
        Positional arguments:
            ui -- reference to the NovelystTk instance of the application.
        """
        self._ui = ui
        self._matrixViewer = None

        # Create a submenu
        self._ui.toolsMenu.insert_command(0, label=APPLICATION, command=self._start_ui)
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')

    def _start_ui(self):
        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                self._matrixViewer.lift()
                self._matrixViewer.focus()
                return

        __, x, y = self._ui.root.geometry().split('+')
        offset = 100
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.pywriter/novelyst/config'
        except:
            configDir = '.'
        self._matrixViewer = MatrixTk(self._ui, windowGeometry, configDir)

    def disable_menu(self):
        """Disable menu entries when no project is open."""
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

    def enable_menu(self):
        """Enable menu entries when a project is open."""
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')

    def on_quit(self):
        """Write back the configuration file."""
        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                self._matrixViewer.on_quit()
