"""A relationship matrix plugin for novelyst

Requires Python 3.6+
Copyright (c) 2022 Peter Triesberger
For further information see https://github.com/peter88213/novelyst_matrix
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
"""
import sys
import os
import gettext
import locale
from pathlib import Path

__all__ = [
           '_',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           'Error',
           'norm_path',
           'string_to_list',
           'list_to_string',
           ]

# Initialize localization.
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
CURRENT_LANGUAGE = locale.getlocale()[0][:2]
try:
    t = gettext.translation('yw-table', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message


class Error(Exception):
    """Base class for exceptions."""


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    """Convert a string into a list with unique elements.
    
    Positional arguments:
        text -- string containing divider-separated substrings.
        
    Optional arguments:
        divider -- string that divides the substrings.
    
    Split a string into a list of strings. Retain the order, but discard duplicates.
    Remove leading and trailing spaces, if any.
    Return a list of strings.
    If an error occurs, return an empty list.
    """
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    """Join strings from a list.
    
    Positional arguments:
        elements -- list of elements to be concatenated.
        
    Optional arguments:
        divider -- string that divides the substrings.
    
    Return a string which is the concatenation of the 
    members of the list of strings "elements", separated by 
    a comma plus a space. The space allows word wrap in 
    spreadsheet cells.
    If an error occurs, return an empty string.
    """
    try:
        text = divider.join(elements)
        return text

    except:
        return ''

import tkinter as tk
from tkinter import messagebox


class Node(tk.Label):
    """A visual matrix node, representing a boolean value.
    
    Class variables:
        isModified -- Boolean: True, if at least one instance has changed its state.
    
    Properties:
        state -- Boolean: Node state. Changes its value and view when clicked on.
    """
    isModified = False
    marker = '⬛'

    def __init__(self, master, colorFalse='white', colorTrue='black', cnf={}, **kw):
        """Place the node to the master widget.
        
        Optional arguments:
            colorBg -- str: Background color.
            colorFg -- str: Marker color when status is True.
        """
        self.colorFg = colorTrue
        self.colorBg = colorFalse
        self._state = False
        super().__init__(master, cnf, **kw)
        self.config(background=self.colorBg)
        self.config(foreground=self.colorFg)
        self.bind('<Control-Button-1>', self._toggle_state)

    @property
    def state(self):
        return self._state

    @state.setter
    def state(self, newState):
        self._state = newState
        self._set_marker()

    def _set_marker(self):
        if self._state:
            self.config(text=self.marker)
        else:
            self.config(text='')

    def _toggle_state(self, event=None):
        self.state = not self._state
        Node.isModified = True


class RelationsTable:
    """Represent a table of relationships. 
    
    Public methods:
        set_nodes -- Loop through all nodes, setting states.
        get_nodes -- Loop through all nodes, modifying the scenes according to the states.
    
    The visual part consists of one frame per column, each containing 
    one node per row. 
    The logical part consists of one dictionary per element type (protected instance variables):
    {scene ID: {element Id: node}}
    """

    def __init__(self, master, novel, **kwargs):
        """Draw the matrix with blank nodes.
        
        Positional arguments:
            novel -- Novel: Project reference.
            
        """

        def fill_str(text):
            """Return a string that is at least 7 characters long.
            
            Extend text with spaces so that it does not fall 
            below the length of 7 characters.
            This is for column titles, to widen narrow columns.
            """
            while len(text) < 7:
                text = f' {text} '
            return text

        colorsBackground = ((kwargs['color_bg_00'], kwargs['color_bg_01']),
                            (kwargs['color_bg_10'], kwargs['color_bg_11']))
        self._novel = novel
        columns = []
        col = 0
        bgc = col % 2

        #--- Scene title column.
        tk.Label(master.topLeft, text=_('Scenes')).pack(fill=tk.X)
        tk.Label(master.topLeft, bg=colorsBackground[1][1], text=' ').pack(fill=tk.X)

        #--- Display titles of "normal" scenes.
        row = 0
        self._arcNodes = {}
        self._characterNodes = {}
        self._locationNodes = {}
        self._itemNodes = {}
        for chId in self._novel.srtChapters:
            for scId in self._novel.chapters[chId].srtScenes:
                bgr = row % 2
                if self._novel.scenes[scId].scType != 0:
                    continue

                #--- Initialize matrix scene row dictionaries.
                self._characterNodes[scId] = {}
                self._locationNodes[scId] = {}
                self._itemNodes[scId] = {}
                self._arcNodes[scId] = {}

                tk.Label(master.rowTitles,
                         text=self._novel.scenes[scId].title,
                         bg=colorsBackground[bgr][1],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(fill=tk.X)
                row += 1
        bgr = row % 2
        tk.Label(master.rowTitles,
                         text=' ',
                         bg=colorsBackground[bgr][1],
                         ).pack(fill=tk.X)
        tk.Label(master.rowTitles,
                         text=' ',
                         ).pack(fill=tk.X)

        #--- Arc columns.
        hasSubplot = False
        self._arcs = []
        self._scnArcs = {}
        for scId in self._arcNodes:
            self._scnArcs[scId] = string_to_list(self._novel.scenes[scId].scnArcs)
            for arc in self._scnArcs[scId]:
                if not arc in self._arcs:
                    self._arcs.append(arc)
            if self._novel.scenes[scId].isSubPlot:
                hasSubplot = True

        self._showSubplot = False
        if hasSubplot and not self._arcs:
            self._showSubplot = True
            self._arcs.append('Subplot')
            for scId in self._arcNodes:
                if self._novel.scenes[scId].isSubPlot:
                    self._scnArcs[scId] = ['Subplot']

        if self._arcs:
            arcTitleWindow = tk.Frame(master.columnTitles)
            arcTitleWindow.pack(side=tk.LEFT, fill=tk.BOTH)
            tk.Label(arcTitleWindow, text=_('Arcs'), bg=kwargs['color_arc_heading']).pack(fill=tk.X)
            arcTypeColumn = tk.Frame(master.display)
            arcTypeColumn.pack(side=tk.LEFT, fill=tk.BOTH)
            arcColumn = tk.Frame(arcTypeColumn)
            arcColumn.pack(fill=tk.BOTH)
            for arc in self._arcs:
                # Display arc titles.
                row = 1
                bgr = row % 2
                bgc = col % 2
                arcTitle = fill_str(arc)
                tk.Label(arcTitleWindow,
                         text=arcTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(side=tk.LEFT, fill=tk.X, expand=True)
                row += 1

                # Display arc nodes.
                columns.append(tk.Frame(arcColumn))
                columns[col].pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
                for scId in self._scnArcs:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=kwargs['color_arc_node']
                         )
                    node.pack(fill=tk.X, expand=True)
                    self._arcNodes[scId][arc] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=arcTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(fill=tk.X, expand=True)
                col += 1
            tk.Label(arcTypeColumn, text=_('Arcs'), bg=kwargs['color_arc_heading']).pack(fill=tk.X)

        #--- Character columns.
        if self._novel.characters:
            characterTypeColumn = tk.Frame(master.display)
            characterTypeColumn.pack(side=tk.LEFT, fill=tk.BOTH)
            characterColumn = tk.Frame(characterTypeColumn)
            characterColumn.pack(fill=tk.BOTH)
            characterTitleWindow = tk.Frame(master.columnTitles)
            characterTitleWindow.pack(side=tk.LEFT, fill=tk.BOTH)
            tk.Label(characterTitleWindow, text=_('Characters'), bg=kwargs['color_character_heading']).pack(fill=tk.X)
            for crId in self._novel.srtCharacters:
                # Display character titles.
                row = 1
                bgr = row % 2
                bgc = col % 2
                characterTitle = fill_str(self._novel.characters[crId].title)
                tk.Label(characterTitleWindow,
                         text=characterTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(side=tk.LEFT, fill=tk.X, expand=True)
                row += 1

                # Display character nodes.
                columns.append(tk.Frame(characterColumn))
                columns[col].pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
                for scId in self._characterNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=kwargs['color_character_node']
                         )
                    node.pack(fill=tk.X, expand=True)
                    self._characterNodes[scId][crId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=characterTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(fill=tk.X, expand=True)
                col += 1
            tk.Label(characterTypeColumn, text=_('Characters'), bg=kwargs['color_character_heading']).pack(fill=tk.X)

        #--- Location columns.
        if self._novel.locations:
            locationTypeColumn = tk.Frame(master.display)
            locationTypeColumn.pack(side=tk.LEFT, fill=tk.BOTH)
            locationColumn = tk.Frame(locationTypeColumn)
            locationColumn.pack(fill=tk.BOTH)
            locationTitleWindow = tk.Frame(master.columnTitles)
            locationTitleWindow.pack(side=tk.LEFT, fill=tk.BOTH)
            tk.Label(locationTitleWindow, text=_('Locations'), bg=kwargs['color_location_heading']).pack(fill=tk.X)
            for lcId in self._novel.srtLocations:
                # Display location titles.
                row = 1
                bgr = row % 2
                bgc = col % 2
                locationTitle = fill_str(self._novel.locations[lcId].title)
                tk.Label(locationTitleWindow,
                         text=locationTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(side=tk.LEFT, fill=tk.X, expand=True)
                row += 1

                # Display location nodes.
                columns.append(tk.Frame(locationColumn))
                columns[col].pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
                for scId in self._locationNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=kwargs['color_location_node']
                         )
                    node.pack(fill=tk.X, expand=True)
                    self._locationNodes[scId][lcId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=locationTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(fill=tk.X, expand=True)
                col += 1
            tk.Label(locationTypeColumn, text=_('Locations'), bg=kwargs['color_location_heading']).pack(fill=tk.X)

        #--- Item columns.
        if self._novel.items:
            itemTypeColumn = tk.Frame(master.display)
            itemTypeColumn.pack(side=tk.LEFT, fill=tk.BOTH)
            itemColumn = tk.Frame(itemTypeColumn)
            itemColumn.pack(fill=tk.BOTH)
            itemTitleWindow = tk.Frame(master.columnTitles)
            itemTitleWindow.pack(side=tk.LEFT, fill=tk.BOTH)
            tk.Label(itemTitleWindow, text=_('Items'), bg=kwargs['color_item_heading']).pack(fill=tk.X)
            for itId in self._novel.srtItems:
                # Display item titles.
                row = 1
                bgr = row % 2
                bgc = col % 2
                itemTitle = fill_str(self._novel.items[itId].title)
                tk.Label(itemTitleWindow,
                         text=itemTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(side=tk.LEFT, fill=tk.X, expand=True)
                row += 1

                # Display item nodes.
                columns.append(tk.Frame(itemColumn))
                columns[col].pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
                for scId in self._itemNodes:
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=kwargs['color_item_node']
                         )
                    node.pack(fill=tk.X, expand=True)
                    self._itemNodes[scId][itId] = node
                    row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=itemTitle,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(fill=tk.X, expand=True)
                col += 1
            tk.Label(itemTypeColumn, text=_('Items'), bg=kwargs['color_item_heading']).pack(fill=tk.X)

    def set_nodes(self):
        """Loop through all nodes, setting states."""
        for scId in self._arcNodes:
            for arc in self._arcs:
                try:
                    self._arcNodes[scId][arc].state = (arc in self._scnArcs[scId])
                except TypeError:
                    pass

        for scId in self._characterNodes:
            for crId in self._novel.characters:
                try:
                    self._characterNodes[scId][crId].state = (crId in self._novel.scenes[scId].characters)
                except TypeError:
                    pass

        for scId in self._locationNodes:
            for lcId in self._novel.locations:
                try:
                    self._locationNodes[scId][lcId].state = (lcId in self._novel.scenes[scId].locations)
                except TypeError:
                    pass

        for scId in self._itemNodes:
            for itId in self._novel.items:
                try:
                    self._itemNodes[scId][itId].state = (itId in self._novel.scenes[scId].items)
                except TypeError:
                    pass

    def get_nodes(self):
        """Loop through all nodes, modifying the scenes according to the states."""
        for scId in self._arcNodes:
            arcs = []
            for arc in self._arcs:
                try:
                    node = self._arcNodes[scId][arc]
                except TypeError:
                    pass
                else:
                    if node.state:
                        arcs.append(arc)
            if self._showSubplot:
                if arcs:
                    self._novel.scenes[scId].isSubPlot = True
                else:
                    self._novel.scenes[scId].isSubPlot = False
            else:
                self._novel.scenes[scId].scnArcs = list_to_string(arcs)

        for scId in self._characterNodes:
            self._novel.scenes[scId].characters = []
            for crId in self._novel.characters:
                try:
                    node = self._characterNodes[scId][crId]
                except TypeError:
                    pass
                else:
                    if node.state:
                        self._novel.scenes[scId].characters.append(crId)

        for scId in self._locationNodes:
            self._novel.scenes[scId].locations = []
            for lcId in self._novel.locations:
                try:
                    node = self._locationNodes[scId][lcId]
                except TypeError:
                    pass
                else:
                    if node.state:
                        self._novel.scenes[scId].locations.append(lcId)

        for scId in self._itemNodes:
            self._novel.scenes[scId].items = []
            for itId in self._novel.items:
                try:
                    node = self._itemNodes[scId][itId]
                except TypeError:
                    pass
                else:
                    if node.state:
                        self._novel.scenes[scId].items.append(itId)

import platform
from tkinter import ttk


class TableFrame(ttk.Frame):
    """A tkinter framew for a scrollable table. 
    
    Public instance variables:
        rowTitles -- ttk.Frame for a vertically scrolled column of row titles. 
        columnTitles -- ttk.Frame for a horizontally scrolled row of column titles. 
        display -- ttk.Frame for columns and rows to be displayed and scrolled in both directions.
        
    """

    def __init__(self, parent, *args, **kw):

        ttk.Frame.__init__(self, parent, *args, **kw)

        # Scrollbars.
        scrollY = ttk.Scrollbar(self, orient=tk.VERTICAL, command=self.yview)
        scrollY.pack(fill=tk.Y, side=tk.RIGHT, expand=False)
        scrollX = ttk.Scrollbar(self, orient=tk.HORIZONTAL, command=self.xview)
        scrollX.pack(fill=tk.X, side=tk.BOTTOM, expand=False)

        # Left column frame.
        leftColFrame = ttk.Frame(self)
        leftColFrame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False)

        # Fixed title column header.
        self.topLeft = ttk.Frame(leftColFrame)
        self.topLeft.pack(anchor=tk.W, fill=tk.X, expand=False)

        #--- Vertically scrollable row titles.
        rowTitlesFrame = ttk.Frame(leftColFrame)
        rowTitlesFrame.pack(fill=tk.BOTH, expand=True)
        self._rowTitlesCanvas = tk.Canvas(rowTitlesFrame, bd=0, highlightthickness=0)
        self._rowTitlesCanvas.configure(yscrollcommand=scrollY.set)
        self._rowTitlesCanvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._rowTitlesCanvas.xview_moveto(0)
        self._rowTitlesCanvas.yview_moveto(0)

        # Create a frame inside the row titles canvas which will be scrolled with it.
        self.rowTitles = ttk.Frame(self._rowTitlesCanvas)
        self._rowTitlesCanvas.create_window(0, 0, window=self.rowTitles, anchor=tk.NW, tags="self.rowTitles")

        def _configure_rowTitles(event):
            # Update the scrollbars to match the size of the display frame.
            size = (self.rowTitles.winfo_reqwidth(), self.rowTitles.winfo_reqheight())
            self._rowTitlesCanvas.config(scrollregion="0 0 %s %s" % size)

            # Update the display Canvas's width to fit the inner frame.
            if self.rowTitles.winfo_reqwidth() != self._rowTitlesCanvas.winfo_width():
                self._rowTitlesCanvas.config(width=self.rowTitles.winfo_reqwidth())

        self.rowTitles.bind('<Configure>', _configure_rowTitles)

        # Right column frame.
        rightColFrame = ttk.Frame(self)
        rightColFrame.pack(side=tk.LEFT, anchor=tk.NW, fill=tk.BOTH, expand=True)

        #--- Horizontally scrollable column titles.
        columnTitlesFrame = ttk.Frame(rightColFrame)
        columnTitlesFrame.pack(fill=tk.X, anchor=tk.NW, expand=False)
        self._columnTitlesCanvas = tk.Canvas(columnTitlesFrame, bd=0, highlightthickness=0)
        self._columnTitlesCanvas.configure(xscrollcommand=scrollX.set)
        self._columnTitlesCanvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._columnTitlesCanvas.xview_moveto(0)
        self._columnTitlesCanvas.yview_moveto(0)

        # Create a frame inside the column titles canvas which will be scrolled with it.
        self.columnTitles = ttk.Frame(self._columnTitlesCanvas)
        self._columnTitlesCanvas.create_window(0, 0, window=self.columnTitles, anchor=tk.NW, tags="self.columnTitles")

        def _configure_columnTitles(event):
            # Update the scrollbars to match the size of the display frame.
            size = (self.columnTitles.winfo_reqwidth(), self.columnTitles.winfo_reqheight())
            self._columnTitlesCanvas.config(scrollregion="0 0 %s %s" % size)

            # Update the display Canvas's width and height to fit the inner frame.
            if self.columnTitles.winfo_reqwidth() != self._columnTitlesCanvas.winfo_width():
                self._columnTitlesCanvas.config(width=self.columnTitles.winfo_reqwidth())
            if self.columnTitles.winfo_reqheight() != self._columnTitlesCanvas.winfo_height():
                self._columnTitlesCanvas.config(height=self.columnTitles.winfo_reqheight())

        self.columnTitles.bind('<Configure>', _configure_columnTitles)

        #--- Vertically and horizontally scrollable display.
        displayFrame = ttk.Frame(rightColFrame)
        displayFrame.pack(fill=tk.BOTH, expand=True)
        self._displayCanvas = tk.Canvas(displayFrame, bd=0, highlightthickness=0)
        self._displayCanvas.configure(xscrollcommand=scrollX.set)
        self._displayCanvas.configure(yscrollcommand=scrollY.set)
        self._displayCanvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._displayCanvas.xview_moveto(0)
        self._displayCanvas.yview_moveto(0)

        # Create a frame inside the display canvas which will be scrolled with it.
        self.display = ttk.Frame(self._displayCanvas)
        self._displayCanvas.create_window(0, 0, window=self.display, anchor=tk.NW, tags="self.display")

        def _configure_display(event):
            # Update the scrollbars to match the size of the display frame.
            size = (self.display.winfo_reqwidth(), self.display.winfo_reqheight())
            self._displayCanvas.config(scrollregion="0 0 %s %s" % size)
            if self.display.winfo_reqwidth() != self._displayCanvas.winfo_width():
                # Update the display Canvas's width to fit the inner frame.
                self._displayCanvas.config(width=self.display.winfo_reqwidth())

        self.display.bind('<Configure>', _configure_display)
        if platform.system() == 'Linux':
            # Vertical scrolling
            self._rowTitlesCanvas.bind_all("<Button-4>", self.on_mouse_wheel)
            self._rowTitlesCanvas.bind_all("<Button-5>", self.on_mouse_wheel)
            self._displayCanvas.bind_all("<Button-4>", self.on_mouse_wheel)
            self._displayCanvas.bind_all("<Button-5>", self.on_mouse_wheel)

            # Horizontal scrolling
            self._rowTitlesCanvas.bind_all("<Shift-Button-4>", self.on_shift_mouse_wheel)
            self._rowTitlesCanvas.bind_all("<Shift-Button-5>", self.on_shift_mouse_wheel)
            self._displayCanvas.bind_all("<Shift-Button-4>", self.on_shift_mouse_wheel)
            self._displayCanvas.bind_all("<Shift-Button-5>", self.on_shift_mouse_wheel)
        else:
            # Vertical scrolling
            self._rowTitlesCanvas.bind_all("<MouseWheel>", self.on_mouse_wheel)
            self._displayCanvas.bind_all("<MouseWheel>", self.on_mouse_wheel)

            # Horizontal scrolling
            self._rowTitlesCanvas.bind_all("<Shift-MouseWheel>", self.on_shift_mouse_wheel)
            self._displayCanvas.bind_all("<Shift-MouseWheel>", self.on_shift_mouse_wheel)

    def yview(self, *args):
        self._rowTitlesCanvas.yview(*args)
        self._displayCanvas.yview(*args)

    def xview(self, *args):
        self._columnTitlesCanvas.xview(*args)
        self._displayCanvas.xview(*args)

    def yview_scroll(self, *args):
        if not self._displayCanvas.yview() == (0.0, 1.0):
            self._rowTitlesCanvas.yview_scroll(*args)
            self._displayCanvas.yview_scroll(*args)

    def xview_scroll(self, *args):
        if not self._displayCanvas.xview() == (0.0, 1.0):
            self._columnTitlesCanvas.xview_scroll(*args)
            self._displayCanvas.xview_scroll(*args)

    def on_mouse_wheel(self, event):
        """Vertical scrolling."""
        if platform.system() == 'Windows':
            self.yview_scroll(int(-1 * (event.delta / 120)), "units")
        elif platform.system() == 'Darwin':
            self.yview_scroll(int(-1 * event.delta), "units")
        else:
            if event.num == 4:
                self.yview_scroll(-1, "units")
            elif event.num == 5:
                self.yview_scroll(1, "units")

    def on_shift_mouse_wheel(self, event):
        """Horizontal scrolling."""
        if platform.system() == 'Windows':
            self.xview_scroll(int(-1 * (event.delta / 120)), "units")
        elif platform.system() == 'Darwin':
            self.xview_scroll(int(-1 * event.delta), "units")
        else:
            if event.num == 4:
                self.xview_scroll(-1, "units")
            elif event.num == 5:
                self.xview_scroll(1, "units")



class TableManager(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')

    def __init__(self, plugin, ui, **kwargs):
        self._ui = ui
        self._ui.refresh_tree()
        self._plugin = plugin
        self._kwargs = kwargs
        super().__init__()

        self._statusText = ''

        self.geometry(kwargs['window_geometry'])
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        self.bind(self._KEY_QUIT_PROGRAM[0], self.on_quit)

        #--- Main menu.
        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        #--- Main window.
        self.mainWindow = TableFrame(self)

        #--- The Relations Table.
        Node.isModified = False
        if self._ui.novel is not None:
            self._relationsTable = RelationsTable(self.mainWindow, self._ui.novel, **self._kwargs)
            self._relationsTable.set_nodes()
        self.isOpen = True
        self.mainWindow.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

    def _apply_changes(self):
        if Node.isModified:
            if messagebox.askyesno(self.title(), f"{_('Apply changes')}?"):
                self._relationsTable.get_nodes()
                self._ui.isModified = True
                self._ui.refresh_tree()

    def on_quit(self, event=None):
        self._apply_changes()
        self._plugin.kwargs['window_geometry'] = self.winfo_geometry()
        self.destroy()
        self.isOpen = False

from configparser import ConfigParser


class Configuration:
    """Application configuration, representing an INI file.

        INI file sections:
        <self._sLabel> - Strings
        <self._oLabel> - Boolean values

    Public methods:
        set(settings={}, options={}) -- set the entire configuration without writing the INI file.
        read(iniFile) -- read a configuration file.
        write(iniFile) -- save the configuration to iniFile.

    Public instance variables:    
        settings - dictionary of strings
        options - dictionary of boolean values
    """

    def __init__(self, settings={}, options={}):
        """Initalize attribute variables.

        Optional arguments:
            settings -- default settings (dictionary of strings)
            options -- default options (dictionary of boolean values)
        """
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def set(self, settings=None, options=None):
        """Set the entire configuration without writing the INI file.

        Optional arguments:
            settings -- new settings (dictionary of strings)
            options -- new options (dictionary of boolean values)
        """
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def read(self, iniFile):
        """Read a configuration file.
        
        Positional arguments:
            iniFile -- str: path configuration file path.
            
        Settings and options that can not be read in, remain unchanged.
        """
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def write(self, iniFile):
        """Save the configuration to iniFile.

        Positional arguments:
            iniFile -- str: path configuration file path.
        """
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)

SETTINGS = dict(
        window_geometry='600x800',
        color_bg_00='gray80',
        color_bg_01='gray85',
        color_bg_10='gray95',
        color_bg_11='white',
        color_arc_heading='royalblue1',
        color_arc_node='royalblue3',
        color_character_heading='goldenrod1',
        color_character_node='goldenrod3',
        color_location_heading='coral1',
        color_location_node='coral3',
        color_item_heading='aquamarine1',
        color_item_node='aquamarine3',
        )
OPTIONS = dict(
        )

# Initialize localization.
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
CURRENT_LANGUAGE = locale.getlocale()[0][:2]
try:
    t = gettext.translation('novelyst_matrix', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Matrix')
PLUGIN = f'{APPLICATION} plugin v0.14.0'


class Plugin:
    """novelyst relationship matrix plugin class.
    
    Public methods:
        disable_menu() -- disable menu entries when no project is open.
        enable_menu() -- enable menu entries when a project is open.   
        on_quit() -- Apply changes and close the window.
        on_close() -- Apply changes and close the window.
    """
    VERSION = '0.14.0'
    NOVELYST_API = '4.0'
    DESCRIPTION = 'A scene relationship table'
    URL = 'https://peter88213.github.io/novelyst_matrix'

    def install(self, ui):
        """Add a submenu to the 'Tools' menu.
        
        Positional arguments:
            ui -- reference to the NovelystTk instance of the application.
        """
        self._ui = ui
        self._matrixViewer = None

        #--- Load configuration.
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.pywriter/novelyst/config'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/matrix.ini'
        self.configuration = Configuration(SETTINGS, OPTIONS)
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        self.kwargs.update(self.configuration.options)

        # Create a submenu
        self._ui.toolsMenu.insert_command(0, label=APPLICATION, command=self._start_ui)
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')

    def _start_ui(self):
        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                self._matrixViewer.lift()
                self._matrixViewer.focus()
                return

        self._matrixViewer = TableManager(self, self._ui, **self.kwargs)
        self._matrixViewer.title(PLUGIN)

    def disable_menu(self):
        """Disable menu entries when no project is open."""
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

    def enable_menu(self):
        """Enable menu entries when a project is open."""
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')

    def on_close(self):
        """Apply changes and close the window."""
        self.on_quit()

    def on_quit(self):
        """Actions to be performed when novelyst is closed."""
        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                self._matrixViewer.on_quit()

        #--- Save project specific configuration
        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)
