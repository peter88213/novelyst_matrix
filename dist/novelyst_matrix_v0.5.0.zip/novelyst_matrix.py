"""A relationship matrix plugin for novelyst

Requires Python 3.6+
Copyright (c) 2022 Peter Triesberger
For further information see https://github.com/peter88213/novelyst_matrix
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)
"""
import os
import sys
import gettext
import locale

__all__ = ['Error',
           '_',
           'norm_path',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           'APPLICATION',
           'PLUGIN',
           ]


class Error(Exception):
    """Base class for exceptions."""


# Initialize localization.
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
CURRENT_LANGUAGE = locale.getlocale()[0][:2]
try:
    t = gettext.translation('novelyst_matrix', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Matrix')
PLUGIN = f'{APPLICATION} plugin v0.5.0'


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)

import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

__all__ = ['Error',
           '_',
           'norm_path',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           ]


class Error(Exception):
    """Base class for exceptions."""


# Initialize localization.
LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
CURRENT_LANGUAGE = locale.getlocale()[0][:2]
try:
    t = gettext.translation('yw-table', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)



class Node(tk.Label):
    """A visual matrix node, representing a boolean value.
    
    Class variables:
        isModified -- Boolean: True, if at least one instance has changed its state.
    
    Properties:
        state -- Boolean: Node state. Changes its value and color when clicked on.
    """
    isModified = False

    def __init__(self, master, colorFalse='white', colorTrue='black', cnf={}, **kw):
        """Place the node to the master widget.
        
        Optional arguments:
            colorFalse -- str: node color when status is False.
            colorTrue -- str: node color when status is True.
        """
        self.colorTrue = colorTrue
        self.colorFalse = colorFalse
        self._state = False
        super().__init__(master, cnf, **kw)
        self._set_color()
        self.bind('<Button-1>', self._toggle_state)

    @property
    def state(self):
        return self._state

    @state.setter
    def state(self, newState):
        self._state = newState
        self._set_color()

    def _set_color(self):
        if self._state:
            self.config(background=self.colorTrue)
        else:
            self.config(background=self.colorFalse)

    def _toggle_state(self, event=None):
        self.state = not self._state
        Node.isModified = True


class RelationsTable:
    """Represent a table of relationships. 
    
    Public methods:
        set_nodes -- Loop through all nodes, setting states.
        get_nodes -- Loop through all nodes, modifying the scenes according to the states.
    
    The visual part consists of one frame per column, each containing 
    one node per row. 
    The logical part consists of one dictionary per element type (protected instance variables):
    {scene ID: {element Id: node}}
    """

    def __init__(self, master, novel):
        """Draw the matrix with blank nodes.
        
        Positional arguments:
            novel -- Novel: Project reference.
            
        """
        self._novel = novel
        colorsBackground = (('white', 'gray95'), ('gray85', 'gray80'))
        colorsArc = (('royalBlue1', 'royalBlue3'), ('royalBlue3', 'royalBlue4'))
        colorsCharacter = (('goldenrod1', 'goldenrod3'), ('goldenrod3', 'goldenrod4'))
        colorsLocation = (('coral1', 'coral3'), ('coral3', 'coral4'))
        colorsItem = (('aquamarine1', 'aquamarine3'), ('aquamarine3', 'aquamarine4'))

        row = 0
        bgr = row % 2
        col = 0
        bgc = col % 2
        columns = []
        self._arcNodes = {}
        self._characterNodes = {}
        self._locationNodes = {}
        self._itemNodes = {}

        #--- Scene title column.
        columns.append(tk.Frame(master))
        columns[col].pack()
        columns[col].pack(side=tk.LEFT, fill=tk.BOTH)
        tk.Label(columns[col], text=_('Scenes'), bg=colorsBackground[1][1]).pack(fill=tk.X)
        tk.Label(columns[col], text=' ', bg=colorsBackground[bgr][bgc]).pack(fill=tk.X)

        #--- Loop through scenes and select the "normal" ones.
        for chId in novel.chapters:
            for scId in novel.chapters[chId].srtScenes:
                if novel.scenes[scId].scType != 0:
                    continue

                #--- Display scene title.
                row += 1
                bgr = row % 2
                tk.Label(columns[col],
                         text=novel.scenes[scId].title,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(fill=tk.X)

                #--- Initialize matrix scene row dictionaries.
                self._characterNodes[scId] = {}
                self._locationNodes[scId] = {}
                self._itemNodes[scId] = {}
                self._arcNodes[scId] = {}

        #--- Arc columns.
        self._arcs = []
        self._scnArcs = {}
        for scId in self._arcNodes:
            if novel.scenes[scId].scnArcs:
                self._scnArcs[scId] = string_to_list(novel.scenes[scId].scnArcs)
                for arc in self._scnArcs[scId]:
                    if not arc in self._arcs:
                        self._arcs.append(arc)
            else:
                self._scnArcs[scId] = []
        if self._arcs:
            arcWindow = tk.Frame(master)
            arcWindow.pack(side=tk.LEFT, fill=tk.BOTH)
            tk.Label(arcWindow, text=_('Arcs'), bg=colorsArc[0][0]).pack(fill=tk.X)
            for arc in self._arcs:
                row = 0
                bgr = row % 2
                col += 1
                bgc = col % 2
                columns.append(tk.Frame(arcWindow))
                columns[col].pack(side=tk.LEFT, fill=tk.BOTH)
                tk.Label(columns[col],
                         text=arc,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(fill=tk.X)
                for scId in self._scnArcs:
                    row += 1
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=colorsArc[bgr][bgc]
                         )
                    node.pack(fill=tk.X)
                    self._arcNodes[scId][arc] = node

        #--- Character columns.
        if novel.characters:
            characterWindow = tk.Frame(master)
            characterWindow.pack(side=tk.LEFT, fill=tk.BOTH)
            tk.Label(characterWindow, text=_('Characters'), bg=colorsCharacter[0][0]).pack(fill=tk.X)
            for crId in novel.characters:
                row = 0
                bgr = row % 2
                col += 1
                bgc = col % 2
                columns.append(tk.Frame(characterWindow))
                columns[col].pack(side=tk.LEFT, fill=tk.BOTH)
                tk.Label(columns[col],
                         text=novel.characters[crId].title,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(fill=tk.X)
                for scId in self._characterNodes:
                    row += 1
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=colorsCharacter[bgr][bgc]
                         )
                    node.pack(fill=tk.X)
                    self._characterNodes[scId][crId] = node

        #--- Location columns.
        if novel.locations:
            locationWindow = tk.Frame(master)
            locationWindow.pack(side=tk.LEFT, fill=tk.BOTH)
            tk.Label(locationWindow, text=_('Locations'), bg=colorsLocation[0][0]).pack(fill=tk.X)
            for lcId in novel.locations:
                row = 0
                bgr = row % 2
                col += 1
                bgc = col % 2
                columns.append(tk.Frame(locationWindow))
                columns[col].pack(side=tk.LEFT, fill=tk.BOTH)
                tk.Label(columns[col],
                         text=novel.locations[lcId].title,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(fill=tk.X)
                for scId in self._locationNodes:
                    row += 1
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=colorsLocation[bgr][bgc]
                         )
                    node.pack(fill=tk.X)
                    self._locationNodes[scId][lcId] = node

        #--- Item columns.
        if novel.items:
            itemWindow = tk.Frame(master)
            itemWindow.pack(side=tk.LEFT, fill=tk.BOTH)
            tk.Label(itemWindow, text=_('Items'), bg=colorsItem[0][0]).pack(fill=tk.X)
            for itId in novel.items:
                row = 0
                bgr = row % 2
                col += 1
                bgc = col % 2
                columns.append(tk.Frame(itemWindow))
                columns[col].pack(side=tk.LEFT, fill=tk.BOTH)
                tk.Label(columns[col],
                         text=novel.items[itId].title,
                         bg=colorsBackground[bgr][bgc],
                         justify=tk.LEFT,
                         anchor=tk.W
                         ).pack(fill=tk.X)
                for scId in self._itemNodes:
                    row += 1
                    bgr = row % 2
                    node = Node(columns[col],
                         colorFalse=colorsBackground[bgr][bgc],
                         colorTrue=colorsItem[bgr][bgc]
                         )
                    node.pack(fill=tk.X)
                    self._itemNodes[scId][itId] = node

    def set_nodes(self):
        """Loop through all nodes, setting states."""
        for scId in self._arcNodes:
            for arc in self._arcs:
                try:
                    self._arcNodes[scId][arc].state = (arc in self._scnArcs[scId])
                except TypeError:
                    pass

        for scId in self._characterNodes:
            for crId in self._novel.characters:
                try:
                    self._characterNodes[scId][crId].state = (crId in self._novel.scenes[scId].characters)
                except TypeError:
                    pass

        for scId in self._locationNodes:
            for lcId in self._novel.locations:
                try:
                    self._locationNodes[scId][lcId].state = (lcId in self._novel.scenes[scId].locations)
                except TypeError:
                    pass

        for scId in self._itemNodes:
            for itId in self._novel.items:
                try:
                    self._itemNodes[scId][itId].state = (itId in self._novel.scenes[scId].items)
                except TypeError:
                    pass

    def get_nodes(self):
        """Loop through all nodes, modifying the scenes according to the states."""
        for scId in self._arcNodes:
            arcs = []
            for arc in self._arcs:
                try:
                    node = self._arcNodes[scId][arc]
                except TypeError:
                    pass
                else:
                    if node.state:
                        arcs.append(arc)
            self._novel.scenes[scId].scnArcs = list_to_string(arcs)

        for scId in self._characterNodes:
            self._novel.scenes[scId].characters = []
            for crId in self._novel.characters:
                try:
                    node = self._characterNodes[scId][crId]
                except TypeError:
                    pass
                else:
                    if node.state:
                        self._novel.scenes[scId].characters.append(crId)

        for scId in self._locationNodes:
            self._novel.scenes[scId].locations = []
            for lcId in self._novel.locations:
                try:
                    node = self._locationNodes[scId][lcId]
                except TypeError:
                    pass
                else:
                    if node.state:
                        self._novel.scenes[scId].locations.append(lcId)

        for scId in self._itemNodes:
            self._novel.scenes[scId].items = []
            for itId in self._novel.items:
                try:
                    node = self._itemNodes[scId][itId]
                except TypeError:
                    pass
                else:
                    if node.state:
                        self._novel.scenes[scId].items.append(itId)


def string_to_list(text, divider=';'):
    """Convert a string into a list with unique elements.
    
    Positional arguments:
        text -- string containing divider-separated substrings.
        
    Optional arguments:
        divider -- string that divides the substrings.
    
    Split a string into a list of strings. Retain the order, but discard duplicates.
    Remove leading and trailing spaces, if any.
    Return a list of strings.
    If an error occurs, return an empty list.
    """
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    """Join strings from a list.
    
    Positional arguments:
        elements -- list of elements to be concatenated.
        
    Optional arguments:
        divider -- string that divides the substrings.
    
    Return a string which is the concatenation of the 
    members of the list of strings "elements", separated by 
    a comma plus a space. The space allows word wrap in 
    spreadsheet cells.
    If an error occurs, return an empty string.
    """
    try:
        text = divider.join(elements)
        return text

    except:
        return ''

from tkinter import ttk


class ScrolledWindow(ttk.Frame):
    """A pure Tkinter scrollable frame that actually works!
    * Use the 'display' attribute to place widgets inside the scrollable frame.
    * Construct and pack/place/grid normally.
    """

    def __init__(self, parent, *args, **kw):
        ttk.Frame.__init__(self, parent, *args, **kw)

        # Create a _canvas object and scrollbars for scrolling it.
        vscrollbar = ttk.Scrollbar(self, orient=tk.VERTICAL)
        vscrollbar.pack(fill=tk.Y, side=tk.RIGHT, expand=tk.FALSE)

        hscrollbar = ttk.Scrollbar(self, orient=tk.HORIZONTAL)
        hscrollbar.pack(fill=tk.X, side=tk.BOTTOM, expand=tk.FALSE)

        self._canvas = tk.Canvas(self, bd=0, highlightthickness=0,
                                 xscrollcommand=hscrollbar.set,
                                 yscrollcommand=vscrollbar.set)
        self._canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=tk.TRUE)

        vscrollbar.config(command=self._canvas.yview)
        hscrollbar.config(command=self._canvas.xview)

        # Reset the view
        self._canvas.xview_moveto(0)
        self._canvas.yview_moveto(0)

        # Create a frame inside the _canvas which will be scrolled with it.
        self.display = ttk.Frame(self._canvas)
        self._display_id = self._canvas.create_window(0, 0, window=self.display, anchor=tk.NW, tags="self.display")
        # Track changes to the _canvas and frame width and sync them,
        # also updating the scrollbar.

        def _configure_display(event):
            # Update the scrollbars to match the size of the inner frame.
            size = (self.display.winfo_reqwidth(), self.display.winfo_reqheight())
            self._canvas.config(scrollregion="0 0 %s %s" % size)
            if self.display.winfo_reqwidth() != self._canvas.winfo_width():
                # Update the _canvas's width to fit the inner frame.
                self._canvas.config(width=self.display.winfo_reqwidth())

        self.display.bind('<Configure>', _configure_display)


SETTINGS = dict(
    last_open='',
    tree_width='300',
)
OPTIONS = {}


class TableManager(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')

    def __init__(self, ui, position):
        self._ui = ui
        super().__init__()

        self.title(PLUGIN)
        self._statusText = ''

        self.geometry(position)
        self.lift()
        self.focus()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        self.bind(self._KEY_QUIT_PROGRAM[0], self.on_quit)

        #--- Main menu.
        self.mainMenu = tk.Menu(self)
        self.config(menu=self.mainMenu)

        #--- Main window.
        self.mainWindow = ScrolledWindow(self)

        #--- The Relations Table.
        Node.isModified = False
        if self._ui.novel is not None:
            self._relationsTable = RelationsTable(self.mainWindow.display, self._ui.novel)
            self._relationsTable.set_nodes()
        self.isOpen = True
        self.mainWindow.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

    def _apply_changes(self):
        if Node.isModified:
            if messagebox.askyesno(PLUGIN, f"{_('Apply changes')}?"):
                self._relationsTable.get_nodes()
                self._ui.isModified = True
                self._ui.refresh_tree()

    def on_quit(self, event=None):
        self._apply_changes()
        self.destroy()
        self.isOpen = False



class Plugin:
    """novelyst relationship matrix plugin class.
    
    Public methods:
        disable_menu() -- disable menu entries when no project is open.
        enable_menu() -- enable menu entries when a project is open.   
        on_quit() -- Apply changes and close the window.
        on_close() -- Apply changes and close the window.
    """
    VERSION = '0.5.0'
    NOVELYST_API = '4.0'
    DESCRIPTION = 'A relationship matrix'
    URL = 'https://peter88213.github.io/novelyst_matrix'

    def install(self, ui):
        """Add a submenu to the 'Tools' menu.
        
        Positional arguments:
            ui -- reference to the NovelystTk instance of the application.
        """
        self._ui = ui
        self._matrixViewer = None

        # Create a submenu
        self._ui.toolsMenu.insert_command(0, label=APPLICATION, command=self._start_ui)
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')

    def _start_ui(self):
        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                self._matrixViewer.lift()
                self._matrixViewer.focus()
                return

        __, x, y = self._ui.root.geometry().split('+')
        offset = 100
        windowGeometry = f'+{int(x)+offset}+{int(y)+offset}'
        self._matrixViewer = TableManager(self._ui, windowGeometry)

    def disable_menu(self):
        """Disable menu entries when no project is open."""
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

    def enable_menu(self):
        """Enable menu entries when a project is open."""
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')

    def on_close(self):
        """Apply changes and close the window."""
        self.on_quit()

    def on_quit(self):
        """Apply changes and close the window."""
        if self._matrixViewer:
            if self._matrixViewer.isOpen:
                self._matrixViewer.on_quit()
